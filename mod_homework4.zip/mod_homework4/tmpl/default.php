<?php

defined('_JEXEC') or die('(@)|(@)');
?>

<ul>
<?php foreach ($list as $item) : ?>
<li><?php echo  $item ;?></li>
<?php endforeach; ?>
</ul>
